# 指尖星空——天文科普网

曾经的网页设计课小组作业。纯手撸静态页面。

网站预览：[https://jyzhu.top/fingerspace](https://jyzhu.top/fingerspace) 。

留在这里作为纪念。

![image](https://user-images.githubusercontent.com/39082096/145727315-1f14565a-23ee-48e6-b5b8-0d481f844005.png)

![image](https://user-images.githubusercontent.com/39082096/145727341-d4753e06-33f9-4bba-9e86-59727a154df9.png)

![image](https://user-images.githubusercontent.com/39082096/145727378-54c42c0c-1cf1-424f-a5c5-f94b67d01d6c.png)

![image](https://user-images.githubusercontent.com/39082096/145727383-88c35f34-09a1-49da-a73b-15c460499826.png)

笑死，当初的个人介绍实在是太黑历史了，已经删掉了，罪过罪过。